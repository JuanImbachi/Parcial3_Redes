# AGARIO_NetworksCourse
It consists in developing a similar game to agar.io using everything that was learned in the first part of the networks course.
